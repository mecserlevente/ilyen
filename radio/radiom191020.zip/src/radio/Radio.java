/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package radio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author felhaszn
 */
public class Radio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int tombsorszam=-1;
    String tomb[][] = new String[1000][5];    
    String tomb2[] = new String[100];
    
    try{
       
        String sor="";
        String tmpsor="xxx";
       
        BufferedReader br=new BufferedReader(new FileReader("veetel.txt")); 
        while((sor=br.readLine())!=null){
            tombsorszam++;

            //rövid sorok kezelése (napazonosító fotósazonosító)
            tomb2 = sor.split(" ");
            tomb[tombsorszam][0] = tomb2[0];
            tomb[tombsorszam][1] = tomb2[1];
        
            //hosszú sorok kezelése (felnőőfarkas/kölyökfarkas szöveg)
           //StringBuilder sorsor=new StringBuilder(br.readLine());
           sor = br.readLine();
            tomb[tombsorszam][4] = sor;
        }
    
    }catch(IOException e){
        System.out.println(e);
    }
    
    /*
    
            System.out.println("tombsorszam: "+tombsorszam);
        System.out.println("sor: "+sor);
        System.out.println("0.index: "+tomb2[0]);
        System.out.println("1.index: "+tomb2[1]);
        System.out.println("hello.");
    */
    
    /*    for (int i = 0; i <= tombsorszam; i++) {
            System.out.println("napok száma: "+tomb[i][0]);
            System.out.println("rádiós száma: "+tomb[i][1]);
            System.out.println("FFarkas száma: "+tomb[i][2]);
            System.out.println("KFarkas száma: "+tomb[i][3]);
            System.out.println(rádióüzenet: "+tomb[i][4]);
            System.out.println("");
        }
     */   
    
        System.out.println("2. feladat megoldása:");
        System.out.println("1.rádióamatőr: "+tomb[0][1]+" utolsó rádióamatőr: "+tomb[tombsorszam][1]);
        System.out.println("");
        
        System.out.println("3. feladat megoldása");
    
        for (int i = 0; i < tombsorszam; i++) {
            if (tomb[i][4].contains("farkas")) {
                System.out.println(tomb[i][0]+" nap "+tomb[i][1]+" rádióamatőr");
            }
        }
        System.out.println("");
        System.out.println("4.feladat");
        
        
        for (int j = 1; j <= 11; j++) {
            int feljegyzesdb=0;
            for (int i = 0; i < tombsorszam; i++) {
                
                if (Integer.parseInt(tomb[i][0]) == j) {
                    feljegyzesdb++;
                }
        }      
            System.out.println(j+". nap rádióamatőrök száma: "+feljegyzesdb);
        }
        
        System.out.println("");
        System.out.println("5.feladat");      
        StringBuilder dekodoltszoveg=new StringBuilder("");
        for (int i = 1; i <= 11; i++) {
            dekodoltszoveg = null;
            for (int j = 0; j < tomb.length; j++) {
                
                if (Integer.parseInt(tomb[j][0]) == i) {
                    System.out.println("helloittvagyok");
                    if (dekodoltszoveg == null) {
                       dekodoltszoveg.append(tomb[j][4]);
                        System.out.println("dekodoltszoveg hossza: "+dekodoltszoveg.length());
                    }
        
                }else{
                       System.out.println("tomb[j][4] tartalma: "+tomb[j][4]);
                       System.out.println("tomb[j][4] hossza: "+tomb[j][4].length());
                    for (int k = 0; k < 90; k++) {
                        if (dekodoltszoveg.charAt(k)=='#') {
                            if (tomb[j][4].charAt(k)=='#') {
                            }else {
                                dekodoltszoveg.setCharAt(k, tomb[j][4].charAt(k));
                            }
                        }
                    }
                
                }
            }
            System.out.println(dekodoltszoveg);
            
        }
        
}}
